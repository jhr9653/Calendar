
insert into Board(user,title,date,content) values("김성택", "안녕하세요", "2018-12-01", "반갑습니다");
insert into Board(user,title,date,content) values("이성택", "안녕히가세요", "2018-12-01", "저도반갑습니다");
